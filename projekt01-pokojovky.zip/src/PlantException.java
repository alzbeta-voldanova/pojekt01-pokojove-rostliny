public class PlantException extends Exception {

    public PlantException(String message) {
        super(message);
    }
}




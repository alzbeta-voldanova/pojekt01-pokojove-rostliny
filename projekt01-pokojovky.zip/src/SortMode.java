public enum SortMode {
    NAME,
    WATERING
}
